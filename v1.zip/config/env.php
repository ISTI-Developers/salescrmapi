<?php
const DEFAULT_DB = 'mysql';

const DB_SERVER = 'localhost';
const DB_USERNAME = 'root';
const DB_PASSWORD = '';
const DB_NAME = 'SALESDB_LIVE';

const QNE_SERVER = '202.57.44.70\\qnebss';
const QNE_USERNAME = 'sa';
const QNE_PASSWORD = 'QnE123!@#';
const QNE_DEFAULT_DB = 'UTASI_LIVEDB';

const UNIS_SERVER = '202.57.44.68';
const UNIS_USERNAME = 'oamsun';
const UNIS_PASSWORD = 'Oams@UN';
const UNIS_DB = 'oams-un';

const COMPANY_DATABASES = [
    "EVERCORP_LIVEDB" => "EVER",
    "LIGHTHOUSE_LIVEDB" => "LEC",
    "UTASI_LIVEDB" => "UTASI",
    "BLMCI_LIVEDB" => "BLMCI",
    "INSPIRE_LIVEDB" => "ILCI",
    "SWIN_LIVEDB" => "SWIN",
    "RTI_LIVE" => "RTI",
    "INNOVONE_LIVE" => "IOI",
    "GATEWAY_LIVE" => "GATEWAY",
    "FFO_LIVE" => "UNFI",
    "TAPADS_LIVE" => "TAMC",
];


const HEADER = [
    'alg' => 'HS256',
    'typ' => 'JWT'
];
const SECRET = 'salescrmapi';

const MAIL_USERNAME = 'vncntkyl.developer@gmail.com';
const MAIL_FROM = 'vncntkyl.developer@gmail.com';
const MAIL_NAME = 'no-reply';
const MAIL_PASSWORD = 'mkxdubmsqroedlkh';

date_default_timezone_set('Asia/Manila');