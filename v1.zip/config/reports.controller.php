<?php
require_once "controller.php";

class ReportsController extends Controller
{
    public function get_reports($user_id = null, $unit_id = null, $status = null)
    {
        $params = [];
        $query = "SELECT r.ID, ui.account_id, CONCAT(ui.first_name, ' ', ui.last_name) as user, su.ID as sales_unit_id, su.unit_name as sales_unit, c.ID as client_id, c.name as client, cm.name as status,r.user_id as editor_id, CONCAT(uin.first_name, ' ', uin.last_name) as editor, r.activity, r.date_submitted 
            FROM clients c
            LEFT JOIN client_misc cm ON c.status = cm.ID
            LEFT JOIN client_accounts ca ON ca.client_id = c.ID
            LEFT JOIN sales_units su ON c.sales_unit_id = su.ID
            LEFT JOIN reports r ON r.client_id = c.ID
            LEFT JOIN user_information ui ON ca.account_id = ui.account_id
			LEFT JOIN user_information uin ON r.user_id = uin.account_id";

        if ($user_id !== null) {
            $query .= " WHERE ca.account_id = ?";
            array_push($params, $user_id);
        }

        if ($unit_id !== null) {
            $query .= " WHERE su.ID = ?";
            array_push($params, $unit_id);
        }
        if ($status !== null) {
            $query .= " WHERE c.status = ?";
            array_push($params, $status);
        }

        $this->setStatement($query);
        $this->statement->execute($params);
        return $this->statement->fetchAll();
    }
    public function get_client_count($sales_unit_id = null, $status = null)
    {
        $query = "SELECT client_misc.name as status, COUNT(*) as count FROM clients JOIN client_misc ON clients.status = client_misc.ID";
        $params = [];

        if ($sales_unit_id !== null) {
            $query .= " WHERE clients.sales_unit_id = ?";
            array_push($params, $sales_unit_id);
        }
        if ($status !== null) {
            $query .= $sales_unit_id !== null ? " AND clients.status = ?" : " WHERE clients.status = ?";
            array_push($params, $status);
        }

        $query .= " GROUP BY client_misc.name;";
        $this->setStatement($query);
        $this->statement->execute(params: $params);
        return $this->statement->fetchAll();
    }

    public function get_report_accesses()
    {
        $this->setStatement("SELECT * FROM report_week_override");
        $this->statement->execute();
        return $this->statement->fetchAll();
    }
    public function insert_report_accesses($week, $year)
    {
        $this->setStatement("INSERT INTO report_week_override (week, year) VALUES (?,?)");
        $this->statement->execute([$week, $year]);
        return $this->statement->fetchAll();
    }

    function insert_report($client_id, $activity, $user_id, $sales_unit_id)
    {
        $this->setStatement("INSERT INTO reports (activity, user_id, sales_unit_id, client_id) VALUES (?,?,?,?)");
        return $this->statement->execute([$activity, $user_id, $sales_unit_id, $client_id]);
        //TODO: Add logging function after successful creation
    }

    public function update_report($activity, $report_id, $user_id, $date)
    {
        $this->setStatement("UPDATE reports SET activity = ?, user_id = ?, date_modified = ? WHERE ID = ?");
        return $this->statement->execute([$activity, $user_id, $date, $report_id]);
    }

    public function delete_report($report_id)
    {
        $this->setStatement("DELETE FROM reports WHERE ID = ?");
        return $this->statement->execute([$report_id]);
    }
}