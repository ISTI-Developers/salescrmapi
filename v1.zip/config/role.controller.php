<?php
require_once "controller.php";

class RoleController extends Controller
{
    function get_roles($role_id = null, $with_description = false)
    {
        $query = "SELECT ur.ID as role_id, rp.ID as role_perm_id, ur.name as role,";

        if ($with_description) {
            $query .= " ur.description, ";
        }

        $query .= "ur.status as status_id, us.name as status, m.ID as module_id, m.name, m.is_parent, m.parent_id, rp.can_view, rp.can_add, rp.can_edit, rp.can_delete 
        FROM user_roles ur LEFT JOIN role_permissions rp ON rp.role_id = ur.ID 
        LEFT JOIN modules m ON m.ID = rp.module_id
        JOIN user_status us ON ur.status = us.ID WHERE ur.status <> 5 ";
        if ($role_id != null) {
            $query .= "AND ur.ID  = ?";
        }
        $this->setStatement($query);

        $this->statement->execute($role_id ? [$role_id] : []);
        return $this->statement->fetchAll();
    }

    function get_modules()
    {
        $this->setStatement("SELECT m.ID as m_id, m.name, us.ID as status_id, us.name as status FROM modules m JOIN user_status us ON us.ID = status WHERE m.is_parent = 1 ORDER BY m.name ASC");
        $this->statement->execute();
        return $this->statement->fetchAll();
    }

    function insert_module($module_name)
    {
        $this->setStatement("INSERT INTO modules (name, is_parent) VALUES (?, 1)");
        if ($this->statement->execute([$module_name])) {
            return $this->connection->lastInsertId();
        } else {
            return false;
        }

    }

    function toggle_module($module_id, $status)
    {
        $this->setStatement("UPDATE modules SET status = ? WHERE ID = ?");
        return $this->statement->execute([$status, $module_id]);
    }

    function check_role_permission($role_id, $module_id)
    {
        $this->setStatement("SELECT * FROM role_permissions WHERE role_id = ? AND module_id = ?");
        $this->statement->execute([$role_id, $module_id]);
        return $this->statement->rowCount() > 0;
    }

    function insert_role_permission($role_id, $module_id, $view, $add, $edit, $delete)
    {
        $this->setStatement("INSERT INTO role_permissions (role_id, module_id, can_view, can_add, can_edit,can_delete) VALUES (?,?,?,?,?,?)");
        return $this->statement->execute([$role_id, $module_id, $view, $add, $edit, $delete]);
    }

    function insert_role($name, $description)
    {
        $this->setStatement("INSERT INTO user_roles (name, description) VALUES (?,?)");
        $this->statement->execute([$name, $description]);
        return $this->connection->lastInsertId();
    }
    function update_role($role_id, $name, $description)
    {
        $this->setStatement("UPDATE user_roles SET name = ?, description = ? WHERE ID = ?");
        return $this->statement->execute([$name, $description, $role_id]);
    }
    function manage_role($role_id, $status_id)
    {
        $this->setStatement("UPDATE user_roles SET status = ? WHERE ID = ?");
        return $this->statement->execute([$status_id, $role_id]);
    }
    function update_role_permission($role_id, $module_id, $view, $add, $edit, $delete)
    {
        $this->setStatement("UPDATE role_permissions SET can_view = ?, can_add = ?, can_edit = ?, can_delete = ? WHERE role_id = ? AND module_id = ?");
        return $this->statement->execute([$view, $add, $edit, $delete, $role_id, $module_id]);
    }
}