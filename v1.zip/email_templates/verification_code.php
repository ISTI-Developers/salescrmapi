<p>
    <span>Hi [name]!</span>
    <br>
    <br>
    Here is your verification code: <b>[code]</b>.
    <br>
    <br>
    If you encounter any issues, feel free to reach out to our support team.
    <br>
    <br>
    Warm Regards,
    <br>
    <br>
    <b><i>Sales CRM Dashboard Admin</i></b><br>
    4th Floor, HPL Building<br>
    #60 Sen. Gil Puyat Ave.<br>
    Makati City, Philippines 1200<br>
</p>