<?php
header('Access-Control-Allow-Origin:*');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json');

require_once "./config/settings.controller.php";
require_once "functions.php";

// Handle preflight request
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    // Send the appropriate headers for the preflight response
    header('HTTP/1.1 200 OK');
    exit();
}

$settings_controller = new SettingsController();

try {
    validate_bearer_token();

    switch ($_SERVER['REQUEST_METHOD']) {
        case "GET":
            if (isset($_GET['access'])) {
                $settings = $settings_controller->get_week_accesses();
            }
            echo json_encode($settings);
            break;
        case "POST":
            if (!isset($_POST['week'])) {
                throw new Exception("Week not found.");
            }
            $result = $settings_controller->unlock_week($_POST['week']);
            if ($result) {
                http_response_code(201); // Created
                echo json_encode([
                    "acknowledged" => (bool) $result,
                    "id" => 0
                ]);
            } else {
                throw new Exception("Failed to unlock week.");
            }

            break;
        case "PUT":

            break;
        case "DELETE":
            if (!isset($_GET['id'])) {
                throw new Exception("ID not found.");
            }
            $result = $settings_controller->lock_week($_GET['id']);
            if ($result) {
                http_response_code(200); // OK
                echo json_encode([
                    "acknowledged" => (bool) $result
                ]);
            } else {
                throw new Exception("Failed to unlock week.");
            }
            break;
    }
} catch (Exception $e) {
    // Output only the error message
    http_response_code(400); // Bad Request
    echo json_encode(['error' => $e->getMessage()]);
}
