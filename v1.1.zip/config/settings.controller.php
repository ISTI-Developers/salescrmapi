<?php
require_once "controller.php";

class SettingsController extends Controller
{
    public function get_week_accesses()
    {
        $this->setStatement("SELECT * FROM report_week_override");
        $this->statement->execute();
        return $this->statement->fetchAll();
    }

    public function unlock_week($week)
    {
        $this->setStatement("INSERT INTO report_week_override (week, year) VALUES (?, YEAR(NOW()))");
        if ($this->statement->execute([$week])) {
            return $this->connection->lastInsertId();
        } else {
            return false;
        }

    }
    public function lock_week($id)
    {
        $this->setStatement("DELETE FROM report_week_override WHERE ID = ?");
        return $this->statement->execute([$id]);
    }
}