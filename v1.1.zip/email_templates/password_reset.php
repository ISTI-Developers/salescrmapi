<p>
    <span>Hi [name]!</span>
    <br>
    <br>
    You have successfully requested a password reset for your Sales CRM Dashboard account.
    <br>
    <br>
    Below is your temporary password:
    <br>
    <br>
    <b>Temporary Password:</b> [temporary_password] <br>
    <br>
    For security reasons, you will be required to change your password upon your next login.
    <br>
    <br>
    If you encounter any issues, feel free to reach out to our support team.
    <br>
    <br>
    Warm Regards,
    <br>
    <br>
    <b><i>Sales CRM Dashboard Admin</i></b><br>
    4th Floor, HPL Building<br>
    #60 Sen. Gil Puyat Ave.<br>
    Makati City, Philippines 1200<br>
</p>
