<p>
    <span>Hi [name]!</span>
    <br>
    <br>
    Welcome to Sales CRM Dashboard. We are excited to have you on board!
    <br>
    <br>
    Below are your login credentials:
    <br>
    <br>
    <b>Username:</b> [username] <br>
    <b>Temporary Password:</b> [temporary_password] <br>
    <br>
    For security reasons, you will be required to change your password upon your first login.
    <br>
    <br>
    If you encounter any issues, feel free to reach out to our support team.
    <br>
    <br>
    Warm Regards,
    <br>
    <br>
    <b><i>Sales CRM Dashboard Admin</i></b><br>
    4th Floor, HPL Building<br>
    #60 Sen. Gil Puyat Ave.<br>
    Makati City, Philippines 1200<br>
</p>