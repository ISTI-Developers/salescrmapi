<?php
header('Access-Control-Allow-Origin:*');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json');

require_once "./config/reports.controller.php";
require_once "functions.php";

// Handle preflight request
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    // Send the appropriate headers for the preflight response
    header('HTTP/1.1 200 OK');
    exit();
}

$reports_controller = new ReportsController();

try {
    validate_bearer_token();

    switch ($_SERVER['REQUEST_METHOD']) {
        case "GET":
            if (isset($_GET['role_id'])) {
                $role_id = intval($_GET['role_id']);
                if (in_array($role_id, [1, 3, 10])) {
                    $reports = $reports_controller->get_reports();
                } else if ($role_id === 4) {
                    $reports = $reports_controller->get_reports(null, $_GET['su_id']);
                } else if ($role_id === 5) {
                    $reports = $reports_controller->get_reports($_GET['user']);
                }
            }
            if (isset($_GET['count'])) {
                $reports = $reports_controller->get_client_count($_GET['count'] == 0 ? null : $_GET['count'], $_GET['status'] ?? null);
            }
            if (isset($_GET['access'])) {
                $reports = $reports_controller->get_report_accesses();
            }
            echo json_encode($reports);
            break;
        case "POST":
            if (!isset($_POST['report'])) {
                throw new Exception("Report not found.");
            }
            $result = $reports_controller->insert_report($_POST['client_id'], $_POST['report'], $_POST['user_id'], $_POST['sales_unit_id']);
            if ($result) {
                http_response_code(201); // Created
                echo json_encode([
                    "acknowledged" => (bool) $result,
                    "id" => $_POST['user_id']
                ]);
            } else {
                throw new Exception("Failed to create report.");
            }

            break;
        case "PUT":
            $contents = json_decode(file_get_contents('php://input'), true);

            if (is_null($contents)) {
                throw new Exception('Data not found.');
            }
            extract($contents);

            $result = $reports_controller->update_report($report, $report_id, $user_id, $date);

            echo json_encode([
                "acknowledged" => (bool) $result,
                "id" => $user_id
            ]);
            break;
        case "DELETE":
            if (!isset($_GET['id'])) {
                throw new Exception("Report ID not found.");
            }
            $result = $reports_controller->delete_report($_GET['id']);
            if ($result) {
                http_response_code(200); // OK
                echo json_encode([
                    "acknowledged" => (bool) $result
                ]);
            } else {
                throw new Exception("Failed to delete report.");
            }
            break;
    }
} catch (Exception $e) {
    // Output only the error message
    http_response_code(400); // Bad Request
    echo json_encode(['error' => $e->getMessage()]);
}
