<?php
header('Access-Control-Allow-Origin:*');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
// header('Content-Type: application/json');

// Handle preflight request
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    // Send the appropriate headers for the preflight response
    header('HTTP/1.1 200 OK');
    exit();
}
require_once __DIR__ . "/config/env.php";
require_once __DIR__ . "/config/contract.controller.php";
require_once __DIR__ . "/config/company.controller.php";

$qne_contracts = new ContractController("sqlsrv", QNE_SERVER, QNE_DEFAULT_DB, QNE_USERNAME, QNE_PASSWORD);
$unis_contracts = new ContractController(server: UNIS_SERVER, dbname: UNIS_DB, username: UNIS_USERNAME, password: UNIS_PASSWORD);
$company_controller = new CompanyController();


$results = (array) $unis_contracts->fetch_available_sites();

// $qne_results = [];
// foreach (COMPANY_DATABASES as $company_db => $data) {
//     array_push($qne_results, (array) $qne_contracts->fetch_contracts_from_qne($company_db));
// }


// $results = array_merge($unis_results, ...$qne_results);


// $results = array_reduce($results, function ($carry, $item) {
//     // Split contract_no by "-"
//     $contract = $item->contract_no;

//     $contract_parts = explode("-", $contract);
//     $contract_prefix = $contract_parts[0] === "SO" ? $contract_parts[0] . "-" . $contract_parts[1] : $contract_parts[0];

//     if (str_contains($contract_prefix, "SO")) {
//         if (count($contract_parts) > 2) {
//             if (is_numeric(substr($contract_parts[2],0,7))) {
//                 $contract_prefix = $contract_prefix . "-" . substr($contract_parts[2],0,7);
//             } else {
//                 if (strlen($contract_parts[2]) > 1) {
//                     $contract_prefix = $contract_prefix . "-" . $contract_parts[2];
//                 }
//             }
//         }
//     }
//     // Initialize the client key if it does not exist
//     if (!isset($carry[$contract_prefix])) {
//         $carry[$contract_prefix] = [];
//     }

//     unset($item->has_addendum);

//     // Add the current item to the array under the correct client name
//     $carry[$contract_prefix][] = $item;

//     return $carry;
// }, []);

// echo json_encode($equal);
// $results = array_intersect($unis_results, $qne_results[0]);
// $contracts = (array) $results;

// print_r($results);

// echo $qne_contracts->connectionError;
// $results = $qne_contracts->fetch_contracts_from_qne();

// foreach ($results as $contract) {
// $contract->client_id = 0;

// $companies = $company_controller->get_companies();
// $company = preg_replace('/[^a-zA-Z0-9\s]/', '', $contract->company);

// $is_company_registered = array_filter($companies, function ($value) use ($company) {
// $stored_company = preg_replace('/[^a-zA-Z0-9\s]/', '', $value->name);
// return stripos($stored_company, $company) !== false;
// });

// // if (count($is_company_registered) > 0) {
// // $stored_company = reset($is_company_registered);
// // $contract->company = $stored_company->company_id;
// // } else {
// // //INSERT COMPANY TO DATABASE AND ADD ITS DETAILS
// // $company_name = $contract->company;
// // $company_code = $company_controller->getCompanyCode($company_name);
// // $company_id = $company_controller->insert_company($company_code, $company_name);
// // $contract->company = $company_id;

// // }
// }

if ($results) {
    echo "<h2>AVAILABLE SITES:</h2>";
    echo "<h3>Row Count " . count($results) . "</h3>";
    echo "<table border='1'>";
    echo "<tr>";
    // Assuming that results have headers, fetch the first row for column names
    if (count($results) > 0) {
        $headers = array_keys(get_object_vars($results[0]));
        foreach ($headers as $header) {
            echo "<th>" . htmlspecialchars($header) . "</th>";
        }
        echo "</tr>";

        // Fetch the rows
        foreach ($results as $row) {
            echo "<tr>";
            foreach ($row as $column) {
                echo "<td>" . htmlspecialchars($column) . "</td>";
            }
            echo "</tr>";
        }
    } else {
        echo "<tr>
<td colspan='100%'>No results found.</td>
</tr>";
    }
    echo "</table>";
} else {
    echo "results not found";
}
